import type { Metadata, Viewport } from "next";
import { Anton, Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";

const anton = Anton({
  weight: "400",
  subsets: ["latin"],
  variable: "--font-anton",
  display: "swap",
});

const plusJakartaSans = Plus_Jakarta_Sans({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
});

export const metadata: Metadata = {
  title: "CHIPSY — Un monde où le croquant prend vie",
  description:
    "Un univers de saveurs fromagées, de personnages malicieux et de croustillant à découvrir.",
  icons: {
    icon: "/favicon.ico",
  },
};

export const viewport: Viewport = {
  themeColor: "#020B2E",
  colorScheme: "dark",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="fr"
      className={`${anton.variable} ${plusJakartaSans.variable} dark h-full antialiased`}
    >
      <body className="min-h-full bg-[#020B2E] text-white overflow-x-hidden selection:bg-amber-400/30 selection:text-white">
        {children}
      </body>
    </html>
  );
}
