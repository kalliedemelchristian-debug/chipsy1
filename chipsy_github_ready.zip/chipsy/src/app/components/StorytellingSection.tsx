"use client";

import { useEffect, useRef, useState } from "react";
import Image from "next/image";

// Smooth cubic easing for cinematic expansion
function easeInOutCubic(x: number): number {
  return x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2;
}

export default function StorytellingSection() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [viewport, setViewport] = useState({ width: 1440, height: 900 });

  // Update viewport dimensions on mount and resize
  useEffect(() => {
    const updateSize = () => {
      setViewport({
        width: window.innerWidth,
        height: window.innerHeight,
      });
    };
    updateSize();
    window.addEventListener("resize", updateSize);
    return () => window.removeEventListener("resize", updateSize);
  }, []);

  // Track scroll position within this storytelling section
  useEffect(() => {
    let animationFrameId: number;
    let target = 0;
    let current = 0;

    const handleScroll = () => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const totalDistance = rect.height - window.innerHeight;
      if (totalDistance <= 0) return;

      const progress = -rect.top / totalDistance;
      target = Math.max(0, Math.min(1, progress));
    };

    const renderLoop = () => {
      const diff = target - current;
      if (Math.abs(diff) > 0.0005) {
        current += diff * 0.14; // Silky smooth lerp
        setScrollProgress(current);
      }
      animationFrameId = requestAnimationFrame(renderLoop);
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll();
    animationFrameId = requestAnimationFrame(renderLoop);

    return () => {
      window.removeEventListener("scroll", handleScroll);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  // Responsive initial 9:16 portrait dimensions
  const isMobile = viewport.width < 640;
  const isTablet = viewport.width >= 640 && viewport.width < 1024;

  const initialWidth = isMobile ? 200 : isTablet ? 260 : 320;
  const initialHeight = Math.round(initialWidth * (16 / 9));

  // Expansion timing (0.0 to 0.72 = expand, 0.72 to 1.0 = full screen immersion)
  const expandProgress = Math.min(1, scrollProgress / 0.72);
  const easedExpand = easeInOutCubic(expandProgress);

  const currentWidth =
    initialWidth + (viewport.width - initialWidth) * easedExpand;
  const currentHeight =
    initialHeight + (viewport.height - initialHeight) * easedExpand;

  const currentRadius = Math.max(0, 24 * (1 - easedExpand * 1.25));
  const borderOpacity = Math.max(0, 1 - easedExpand * 2.5);

  // Subtle zoom during the full screen immersion state (0.72 -> 1.0)
  const immersionProgress = Math.max(
    0,
    (scrollProgress - 0.72) / (1 - 0.72 || 1)
  );
  const imageScale = 1 + immersionProgress * 0.06;

  // Helper for staggered exit animations of informational text elements
  const getTagStyle = (
    startP: number,
    endP: number,
    translateX: number,
    translateY: number,
    rotateOffset: number,
    initialRotate: number
  ) => {
    if (scrollProgress <= startP) {
      return {
        opacity: 1,
        transform: `translate3d(0px, 0px, 0) rotate(${initialRotate}deg) scale(1)`,
        transition: "opacity 0.2s ease-out",
      };
    }
    if (scrollProgress >= endP) {
      return {
        opacity: 0,
        pointerEvents: "none" as const,
        transform: `translate3d(${translateX}px, ${translateY}px, 0) rotate(${
          initialRotate + rotateOffset
        }deg) scale(0.85)`,
      };
    }
    const t = (scrollProgress - startP) / (endP - startP);
    const ease = t * t; // smooth ease-in
    return {
      opacity: Math.max(0, 1 - ease),
      transform: `translate3d(${translateX * ease}px, ${
        translateY * ease
      }px, 0) rotate(${initialRotate + rotateOffset * ease}deg) scale(${
        1 - 0.15 * ease
      })`,
    };
  };

  return (
    <section
      ref={containerRef}
      id="univers"
      className="relative w-full h-[340vh] bg-black select-none"
    >
      {/* Pinned Sticky Viewport */}
      <div className="sticky top-0 h-[100dvh] w-full overflow-hidden bg-black flex items-center justify-center">
        {/* Subtle Ambient Cosmic Cheese Light behind the portrait */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[70vw] max-w-[800px] h-[70vh] max-h-[800px] rounded-full blur-[140px] opacity-40 transition-opacity duration-700"
          style={{
            opacity: 0.35 * (1 - scrollProgress * 0.5),
            background:
              "radial-gradient(circle, rgba(245, 158, 11, 0.28) 0%, rgba(37, 99, 235, 0.15) 50%, transparent 75%)",
          }}
        />

        {/* ===================================================================
            ORGANIZED CHAOS EDITORIAL TEXT ELEMENTS (AROUND INITIAL PORTRAIT)
           =================================================================== */}

        {/* 1. Top-Left Badge: Chapter & Genesis */}
        <div
          className="absolute z-20 pointer-events-none"
          style={{
            top: isMobile ? "6%" : "10%",
            left: isMobile ? "5%" : "8%",
            ...getTagStyle(0.04, 0.35, -50, -35, -5, -3),
          }}
        >
          <div className="inline-flex flex-col gap-1 p-3 sm:p-4 rounded-2xl bg-white/[0.04] border border-amber-500/25 backdrop-blur-xl shadow-2xl max-w-[210px] sm:max-w-[260px]">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse shadow-[0_0_8px_rgba(251,191,36,0.9)]" />
              <span className="text-[10px] sm:text-xs font-semibold uppercase tracking-widest text-amber-400">
                Chapitre II // Genèse
              </span>
            </div>
            <h3 className="font-[family-name:var(--font-anton)] text-base sm:text-lg tracking-wide text-white uppercase mt-0.5">
              La Grotte aux Saveurs
            </h3>
            <p className="text-[11px] sm:text-xs text-white/60 font-light leading-snug">
              Là où le fromage doré fusionne avec l&apos;énergie cosmique.
            </p>
          </div>
        </div>

        {/* 2. Top-Right Stat & Temperature */}
        <div
          className="absolute z-20 pointer-events-none text-right"
          style={{
            top: isMobile ? "7%" : "11%",
            right: isMobile ? "5%" : "8%",
            ...getTagStyle(0.06, 0.38, 55, -30, 6, 4),
          }}
        >
          <div className="inline-flex flex-col items-end gap-0.5 p-3 sm:p-4 rounded-2xl bg-white/[0.03] border border-white/10 backdrop-blur-xl">
            <span className="text-[10px] sm:text-[11px] uppercase tracking-widest text-white/50 font-mono">
              Température de Fusion
            </span>
            <div className="font-[family-name:var(--font-anton)] text-2xl sm:text-4xl text-amber-400 tracking-tight">
              850°C
            </div>
            <span className="text-[10px] sm:text-xs text-white/70 font-medium">
              Vortex Fromager Actif
            </span>
          </div>
        </div>

        {/* 3. Mid-Left Editorial Narrative (Hidden on very small mobile to prevent clutter) */}
        <div
          className="hidden sm:block absolute z-20 pointer-events-none"
          style={{
            top: "42%",
            left: isTablet ? "4%" : "7%",
            ...getTagStyle(0.1, 0.44, -70, -10, -4, 2),
          }}
        >
          <div className="max-w-[220px] lg:max-w-[260px] pl-3.5 border-l-2 border-amber-400/60">
            <span className="text-[10px] uppercase font-mono tracking-widest text-amber-400/90 block mb-1">
              Archive N°049
            </span>
            <p className="text-xs lg:text-sm text-white/80 font-light italic leading-relaxed">
              « Au premier craquement, le sanctuaire s’illumine. La mascotte
              prend vie dans un tourbillon d’or fondu. »
            </p>
          </div>
        </div>

        {/* 4. Mid-Right Spec / Character File */}
        <div
          className="hidden sm:block absolute z-20 pointer-events-none"
          style={{
            top: "44%",
            right: isTablet ? "4%" : "7%",
            ...getTagStyle(0.12, 0.46, 70, 15, 4, -2.5),
          }}
        >
          <div className="p-3.5 sm:p-4 rounded-2xl bg-white/[0.03] border border-white/10 backdrop-blur-xl max-w-[230px] lg:max-w-[270px]">
            <div className="text-[10px] uppercase tracking-widest font-mono text-cyan-400 mb-1">
              SPEC // ENTITÉ MALICIEUSE
            </div>
            <div className="font-[family-name:var(--font-anton)] text-sm sm:text-base text-white tracking-wide uppercase">
              Rongeur d&apos;Élite
            </div>
            <div className="mt-2 flex items-center justify-between text-[11px] text-white/60">
              <span>Croquant</span>
              <span className="text-amber-400 font-semibold">100% Absolu</span>
            </div>
            <div className="w-full bg-white/10 h-1 rounded-full mt-1 overflow-hidden">
              <div className="bg-gradient-to-r from-amber-400 to-orange-500 h-full w-[95%]" />
            </div>
          </div>
        </div>

        {/* 5. Bottom-Left Badge: Recipe & Crunch */}
        <div
          className="absolute z-20 pointer-events-none"
          style={{
            bottom: isMobile ? "8%" : "12%",
            left: isMobile ? "5%" : "8%",
            ...getTagStyle(0.14, 0.5, -45, 40, -4, -1.5),
          }}
        >
          <div className="flex items-center gap-3 py-2.5 px-4 rounded-full bg-white/[0.04] border border-white/15 backdrop-blur-md">
            <span className="text-base sm:text-lg">🧀</span>
            <div className="flex flex-col">
              <span className="text-[11px] sm:text-xs font-semibold text-white tracking-tight">
                Alvéoles Croustillantes
              </span>
              <span className="text-[9px] sm:text-[10px] text-white/50 uppercase tracking-widest font-mono">
                Texture Brevetée Chipsy
              </span>
            </div>
          </div>
        </div>

        {/* 6. Bottom-Right Signature / Quote */}
        <div
          className="absolute z-20 pointer-events-none text-right"
          style={{
            bottom: isMobile ? "9%" : "12%",
            right: isMobile ? "5%" : "8%",
            ...getTagStyle(0.16, 0.54, 50, 45, 5, 3),
          }}
        >
          <div className="max-w-[220px] sm:max-w-[270px]">
            <p className="text-xs sm:text-sm text-white/80 font-light leading-snug">
              « Quand le fromage s’éveille, le silence s’effondre. »
            </p>
            <span className="text-[10px] uppercase tracking-wider text-amber-400/80 font-mono mt-1 block">
              — Les Ateliers Chipsy
            </span>
          </div>
        </div>

        {/* Subtle Initial Scroll Prompt (Fades out immediately as scrolling starts) */}
        <div
          className="absolute bottom-5 left-1/2 -translate-x-1/2 z-20 pointer-events-none transition-opacity duration-300 flex flex-col items-center gap-1.5"
          style={{
            opacity: Math.max(0, 1 - scrollProgress * 7),
          }}
        >
          <span className="text-[10px] sm:text-[11px] uppercase tracking-[0.2em] text-white/40 font-mono">
            Faites défiler pour révéler
          </span>
          <span className="w-1 h-3 rounded-full bg-amber-400/70 animate-bounce" />
        </div>

        {/* ===================================================================
            CENTERPIECE: PORTRAIT (9:16) TO FULLSCREEN EXPANDING IMAGE
           =================================================================== */}
        <div
          className="relative z-10 overflow-hidden flex items-center justify-center transition-shadow duration-500 will-change-transform"
          style={{
            width: `${currentWidth}px`,
            height: `${currentHeight}px`,
            borderRadius: `${currentRadius}px`,
            boxShadow:
              borderOpacity > 0.05
                ? `0 20px 80px rgba(0, 0, 0, 0.9), 0 0 50px rgba(245, 158, 11, ${
                    0.25 * borderOpacity
                  })`
                : "none",
            border:
              borderOpacity > 0.05
                ? `1px solid rgba(255, 255, 255, ${0.18 * borderOpacity})`
                : "none",
          }}
        >
          {/* Inner Image Container with Focal-Point Preserving Cover & Cinematic Zoom */}
          <div
            className="relative w-full h-full will-change-transform"
            style={{
              transform: `scale(${imageScale})`,
              transition: "transform 0.15s ease-out",
            }}
          >
            <Image
              src="/images/chipsy-universe.jpg"
              alt="L'Univers Immersif de Chipsy"
              fill
              priority
              sizes="100vw"
              className="object-cover object-center select-none"
            />

            {/* Subtle Vignette on edges during expansion to enhance depth */}
            <div
              className="pointer-events-none absolute inset-0 transition-opacity duration-700"
              style={{
                opacity: 0.45 * (1 - easedExpand * 0.4),
                background:
                  "radial-gradient(circle at center, transparent 40%, rgba(0, 0, 0, 0.75) 100%)",
              }}
            />
          </div>
        </div>

        {/* Subtle Minimalist Exhibition Overlay at Full Immersion (p > 0.85) */}
        <div
          className="absolute bottom-8 left-8 sm:bottom-12 sm:left-12 z-30 pointer-events-none transition-opacity duration-700"
          style={{
            opacity: Math.max(0, (scrollProgress - 0.82) / 0.15),
          }}
        >
          <div className="flex items-center gap-3">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400 shadow-[0_0_12px_rgba(251,191,36,1)] animate-pulse" />
            <span className="font-[family-name:var(--font-anton)] text-lg sm:text-2xl text-white tracking-widest uppercase">
              L&apos;Univers Croustillant
            </span>
          </div>
          <p className="text-xs sm:text-sm text-white/70 font-light mt-1 max-w-sm">
            Une immersion totale où le croustillant défie la gravité.
          </p>
        </div>
      </div>
    </section>
  );
}
