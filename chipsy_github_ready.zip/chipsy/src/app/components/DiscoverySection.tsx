"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";

interface SpecimenCard {
  id: string;
  code: string;
  number: string;
  name: string;
  flavor: string;
  category: string;
  description: string;
  coordinates: string;
  intensity: string;
  imageSrc: string;
  imageAspect: string;
  isHero?: boolean;
  accentColor: string;
  glowColor: string;
  rotation: string;
}

const specimens: SpecimenCard[] = [
  {
    id: "hero-fromage",
    code: "SPEC-01 // ARCHIVE BLEUE",
    number: "01",
    name: "Fromage Mauve Original",
    flavor: "Goût Fromage Intense",
    category: "SPÉCIMEN 01 — L'ORIGINE BLEUE",
    description:
      "Le sachet matriciel. Une déflagration de fromage intense infusé dans un tourbillon d'or croustillant. La référence absolue qui a éveillé le monde Chipsy.",
    coordinates: "48°51'24\"N 02°21'07\"E",
    intensity: "98% PUR CROQUANT",
    imageSrc: "/images/discovery/specimen-hero-fromage.jpg",
    imageAspect: "aspect-[4/5]",
    isHero: true,
    accentColor: "from-blue-500 to-indigo-600",
    glowColor: "rgba(37, 99, 235, 0.4)",
    rotation: "hover:-rotate-1",
  },
  {
    id: "chipo-mascot",
    code: "SPEC-00 // RELIQUE VIVANTE",
    number: "00",
    name: "Chipo la Mascotte",
    flavor: "Esprit Espiègle & Protecteur",
    category: "SPÉCIMEN 00 — L'ESPRIT DU CROQUANT",
    description:
      "Le gardien rongeur aux oreilles de velours. Porteur de la relique fromagère ancestrale, il guide les explorateurs vers le croustillant suprême.",
    coordinates: "45°45'35\"N 04°50'32\"E",
    intensity: "ÉNERGIE COSMIQUE",
    imageSrc: "/images/discovery/specimen-chipo.jpg",
    imageAspect: "aspect-[16/10]",
    accentColor: "from-amber-400 to-orange-500",
    glowColor: "rgba(245, 158, 11, 0.35)",
    rotation: "hover:rotate-1",
  },
  {
    id: "popcheese",
    code: "SPEC-02 // VOIE LACTÉE",
    number: "02",
    name: "Popcheese Fromage Blanc",
    flavor: "Douceur Fromage Blanc",
    category: "SPÉCIMEN 02 — SAVEUR BLANCHE",
    description:
      "Une texture alvéolée d'une légèreté vaporeuse. Une douceur crémeuse et aérienne, née des souffles purs des prairies célestes.",
    coordinates: "43°17'47\"N 05°22'12\"E",
    intensity: "TEXTURE VAPOREUSE",
    imageSrc: "/images/discovery/specimen-popcheese.jpg",
    imageAspect: "aspect-[4/5]",
    accentColor: "from-emerald-400 to-teal-500",
    glowColor: "rgba(20, 184, 166, 0.25)",
    rotation: "hover:rotate-1",
  },
  {
    id: "emmental",
    code: "SPEC-03 // NOBLESSE DORÉE",
    number: "03",
    name: "Emmental Doré",
    flavor: "Emmental Affiné",
    category: "SPÉCIMEN 03 — CŒUR AFFINÉ",
    description:
      "Des cavités sculptées dans l'ambre noble. Chaque bouchée libère des notes boisées et fruitées qui résonnent au palais.",
    coordinates: "47°13'05\"N 01°33'10\"W",
    intensity: "AFFINAGE SUPRÊME",
    imageSrc: "/images/discovery/specimen-emmental.jpg",
    imageAspect: "aspect-[4/5]",
    accentColor: "from-amber-500 to-yellow-400",
    glowColor: "rgba(234, 179, 8, 0.3)",
    rotation: "hover:-rotate-1",
  },
  {
    id: "popcorn",
    code: "SPEC-04 // ÉCLAT SOLAIRE",
    number: "04",
    name: "Popcorn Maïs Soufflé",
    flavor: "Maïs Grillé & Craquant",
    category: "SPÉCIMEN 04 — LE SOUFFLE DORÉ",
    description:
      "Quand le grain de soleil éclate sous l'ardeur du vortex volcanique pour donner naissance à un nuage doré croustillant et sucré-salé.",
    coordinates: "44°50'16\"N 00°34'46\"W",
    intensity: "SOUFFLE CRÉPITANT",
    imageSrc: "/images/discovery/specimen-popcorn.jpg",
    imageAspect: "aspect-[4/5]",
    accentColor: "from-rose-500 to-amber-500",
    glowColor: "rgba(244, 63, 94, 0.25)",
    rotation: "hover:rotate-1",
  },
];

export default function DiscoverySection() {
  const [activeCard, setActiveCard] = useState<string | null>(null);

  return (
    <section
      id="saveurs"
      className="relative w-full bg-[#010411] text-white py-24 sm:py-32 lg:py-40 overflow-hidden select-none"
    >
      {/* =========================================================================
          BACKGROUND AMBIENCE & OVERSIZED FLOATING WORDS
         ========================================================================= */}
      {/* Deep brand gradient glow */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-[600px] rounded-full blur-[160px] opacity-25"
        style={{
          background:
            "radial-gradient(ellipse at center, rgba(37, 99, 235, 0.35) 0%, rgba(2, 11, 46, 0.8) 60%, transparent 100%)",
        }}
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute bottom-1/4 right-0 w-[500px] h-[500px] rounded-full blur-[140px] opacity-15"
        style={{
          background: "radial-gradient(circle, #F59E0B 0%, transparent 70%)",
        }}
      />

      {/* Oversized floating editorial watermark words */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute top-28 left-4 font-[family-name:var(--font-anton)] text-[15vw] leading-none text-white/[0.015] tracking-tight uppercase select-none"
      >
        CROQUANT
      </div>
      <div
        aria-hidden="true"
        className="pointer-events-none absolute top-[45%] right-6 font-[family-name:var(--font-anton)] text-[16vw] leading-none text-blue-500/[0.025] tracking-tight uppercase select-none"
      >
        FROMAGE
      </div>
      <div
        aria-hidden="true"
        className="pointer-events-none absolute bottom-40 left-12 font-[family-name:var(--font-anton)] text-[15vw] leading-none text-amber-500/[0.02] tracking-tight uppercase select-none"
      >
        SAVEUR
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-10 lg:px-16">
        {/* =========================================================================
            HEADER & MYSTERIOUS INTRO
           ========================================================================= */}
        <div className="flex flex-col items-start max-w-3xl mb-16 sm:mb-20 lg:mb-28">
          {/* Small archive pill badge */}
          <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-blue-950/60 border border-blue-500/30 backdrop-blur-md mb-6">
            <span className="w-2 h-2 rounded-full bg-blue-400 shadow-[0_0_8px_rgba(96,165,250,0.9)] animate-pulse" />
            <span className="text-xs font-mono uppercase tracking-[0.2em] text-blue-300">
              CHIPSY DISCOVERY // ARCHIVE DIGITALE
            </span>
          </div>

          {/* Large elegant title */}
          <h2 className="font-[family-name:var(--font-anton)] text-5xl sm:text-7xl lg:text-8xl tracking-tight text-white uppercase leading-[0.9] mb-6">
            DÉCOUVREZ <span className="text-blue-400">CHIPSY</span>
          </h2>

          {/* Mysterious French intro */}
          <p className="text-base sm:text-lg lg:text-xl text-white/70 font-light leading-relaxed max-w-2xl">
            Entrez dans les archives secrètes du croustillant. Entre recettes
            légendaires, terroirs imaginaires et créatures malicieuses, chaque
            spécimen recèle une intensité fromagère prête à éclater au moindre
            craquement.
          </p>

          {/* Archival metadata line */}
          <div className="flex flex-wrap items-center gap-6 mt-6 pt-6 border-t border-white/10 text-[11px] font-mono text-white/40 uppercase tracking-widest">
            <span>INDEX: ARCH-CHIPSY-2026</span>
            <span>CLASSEMENT: SECRET SAVEUR</span>
            <span>ENTITÉS: 05 IDENTIFIÉES</span>
          </div>
        </div>

        {/* =========================================================================
            ASYMMETRIC EDITORIAL GRID (5 CARDS)
           ========================================================================= */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 lg:gap-8 items-start">
          {/* ---------------------------------------------------------------------
              HERO CARD (Row 1, Columns 1 to 7): Blue Sachet "Fromage / Mauve"
             --------------------------------------------------------------------- */}
          <div
            onMouseEnter={() => setActiveCard("hero-fromage")}
            onMouseLeave={() => setActiveCard(null)}
            className={`group md:col-span-7 relative rounded-3xl p-6 sm:p-8 lg:p-10 transition-all duration-500 cursor-pointer overflow-hidden backdrop-blur-2xl ${
              specimens[0].rotation
            } ${
              activeCard === "hero-fromage"
                ? "shadow-[0_0_60px_rgba(37,99,235,0.45)] border-blue-400/70 -translate-y-2"
                : "border-blue-500/40 shadow-[0_0_35px_rgba(37,99,235,0.2)]"
            } bg-gradient-to-br from-[#07174A]/90 via-[#030B29]/95 to-[#010414] border`}
          >
            {/* Subtle blue ambient aura inside hero card */}
            <div
              aria-hidden="true"
              className="pointer-events-none absolute -top-20 -right-20 w-80 h-80 rounded-full blur-[100px] bg-blue-500/30 group-hover:bg-blue-400/45 transition-colors duration-500"
            />

            {/* Card Header Metadata */}
            <div className="flex items-center justify-between gap-4 mb-6 relative z-10">
              <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/15 border border-blue-400/30 text-[11px] font-mono font-medium text-blue-300 uppercase tracking-widest">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse" />
                {specimens[0].category}
              </span>
              <span className="text-xs font-mono text-white/40">
                {specimens[0].coordinates}
              </span>
            </div>

            {/* Specimen Presentation Frame */}
            <div className="relative z-10 w-full h-[320px] sm:h-[380px] lg:h-[420px] rounded-2xl bg-white/[0.03] border border-white/[0.06] overflow-hidden flex items-center justify-center p-6 mb-8 group-hover:border-blue-500/30 transition-colors duration-500">
              <div className="relative w-full h-full">
                <Image
                  src={specimens[0].imageSrc}
                  alt={specimens[0].name}
                  fill
                  sizes="(max-width: 768px) 100vw, 55vw"
                  className="object-contain filter drop-shadow-[0_20px_40px_rgba(0,0,0,0.8)] group-hover:scale-105 group-hover:rotate-1 transition-all duration-500"
                />
              </div>

              {/* Floating watermark badge */}
              <div className="absolute bottom-3 left-3 text-[10px] font-mono text-white/30 uppercase tracking-widest">
                HERO SPECIMEN // 01
              </div>
              <div className="absolute top-3 right-3 px-2 py-0.5 rounded bg-blue-500/20 text-[9px] font-mono text-blue-300">
                INTENSITÉ 98%
              </div>
            </div>

            {/* Card Details & Typography */}
            <div className="relative z-10 flex flex-col gap-3">
              <div className="flex items-baseline justify-between gap-2">
                <h3 className="font-[family-name:var(--font-anton)] text-3xl sm:text-4xl lg:text-5xl uppercase tracking-tight text-white group-hover:text-blue-300 transition-colors duration-300">
                  {specimens[0].name}
                </h3>
                <span className="text-xs font-mono uppercase tracking-widest text-blue-400 font-semibold">
                  {specimens[0].flavor}
                </span>
              </div>

              <p className="text-sm sm:text-base text-white/70 font-light leading-relaxed">
                {specimens[0].description}
              </p>

              {/* Expandable Hover Metadata */}
              <div className="mt-4 pt-4 border-t border-white/10 flex items-center justify-between text-xs font-mono text-white/50">
                <span className="group-hover:text-amber-400 transition-colors">
                  COMPOSITION: 100% MAÏS CROQUANT & FROMAGE
                </span>
                <span className="group-hover:translate-x-1 transition-transform duration-300 text-blue-300 font-semibold flex items-center gap-1">
                  Explorer la fiche →
                </span>
              </div>
            </div>
          </div>

          {/* ---------------------------------------------------------------------
              CARD 2 (Row 1, Columns 8 to 12): Chipo Mascot
             --------------------------------------------------------------------- */}
          <div
            onMouseEnter={() => setActiveCard("chipo-mascot")}
            onMouseLeave={() => setActiveCard(null)}
            className={`group md:col-span-5 relative rounded-3xl p-6 sm:p-8 transition-all duration-500 cursor-pointer overflow-hidden backdrop-blur-2xl ${
              specimens[1].rotation
            } ${
              activeCard === "chipo-mascot"
                ? "shadow-[0_0_50px_rgba(245,158,11,0.35)] border-amber-400/60 -translate-y-2"
                : "border-white/10 shadow-2xl"
            } bg-gradient-to-br from-[#120E2E]/90 via-[#0A071E]/95 to-[#010410] border`}
          >
            {/* Warm amber aura inside mascot card */}
            <div
              aria-hidden="true"
              className="pointer-events-none absolute -top-16 -left-16 w-60 h-60 rounded-full blur-[90px] bg-amber-500/25 group-hover:bg-amber-400/40 transition-colors duration-500"
            />

            {/* Header Metadata */}
            <div className="flex items-center justify-between gap-4 mb-6 relative z-10">
              <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-400/30 text-[11px] font-mono font-medium text-amber-300 uppercase tracking-widest">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                {specimens[1].category}
              </span>
              <span className="text-xs font-mono text-white/40">N°00</span>
            </div>

            {/* Specimen Frame */}
            <div className="relative z-10 w-full h-[280px] sm:h-[320px] rounded-2xl bg-white/[0.03] border border-white/[0.06] overflow-hidden flex items-center justify-center p-4 mb-6 group-hover:border-amber-500/30 transition-colors duration-500">
              <div className="relative w-full h-full">
                <Image
                  src={specimens[1].imageSrc}
                  alt={specimens[1].name}
                  fill
                  sizes="(max-width: 768px) 100vw, 40vw"
                  className="object-contain filter drop-shadow-[0_15px_30px_rgba(0,0,0,0.8)] group-hover:scale-105 group-hover:-rotate-1 transition-all duration-500"
                />
              </div>
              <div className="absolute bottom-3 left-3 text-[10px] font-mono text-amber-400/70 uppercase tracking-widest">
                GARDIEN ASTUCE // CROUSTY
              </div>
            </div>

            {/* Content */}
            <div className="relative z-10 flex flex-col gap-2.5">
              <div className="flex items-baseline justify-between gap-2">
                <h3 className="font-[family-name:var(--font-anton)] text-2xl sm:text-3xl lg:text-4xl uppercase tracking-tight text-white group-hover:text-amber-300 transition-colors duration-300">
                  {specimens[1].name}
                </h3>
              </div>
              <p className="text-xs sm:text-sm text-white/70 font-light leading-relaxed">
                {specimens[1].description}
              </p>

              <div className="mt-3 pt-3 border-t border-white/10 flex items-center justify-between text-xs font-mono text-white/50">
                <span className="text-amber-400/80">RELIQUE: CROQUANT D'OR</span>
                <span className="text-white/80 group-hover:translate-x-1 transition-transform">
                  Rencontrer →
                </span>
              </div>
            </div>
          </div>

          {/* ---------------------------------------------------------------------
              CARD 3 (Row 2, Columns 1 to 4): Popcheese Fromage Blanc
             --------------------------------------------------------------------- */}
          <div
            onMouseEnter={() => setActiveCard("popcheese")}
            onMouseLeave={() => setActiveCard(null)}
            className={`group md:col-span-4 relative rounded-3xl p-6 sm:p-7 transition-all duration-500 cursor-pointer overflow-hidden backdrop-blur-2xl ${
              specimens[2].rotation
            } ${
              activeCard === "popcheese"
                ? "shadow-[0_0_40px_rgba(20,184,166,0.3)] border-teal-400/60 -translate-y-2"
                : "border-white/10 shadow-2xl"
            } bg-gradient-to-br from-[#06182B]/90 via-[#030F1E]/95 to-[#010410] border`}
          >
            <div className="flex items-center justify-between gap-4 mb-5 relative z-10">
              <span className="text-[10px] font-mono font-medium text-teal-300 uppercase tracking-widest px-2.5 py-0.5 rounded bg-teal-500/10 border border-teal-400/20">
                {specimens[2].category}
              </span>
              <span className="text-[11px] font-mono text-white/40">
                N°02 // LAIT
              </span>
            </div>

            <div className="relative z-10 w-full h-[230px] sm:h-[260px] rounded-2xl bg-white/[0.03] border border-white/[0.06] overflow-hidden flex items-center justify-center p-4 mb-5 group-hover:border-teal-400/30 transition-colors">
              <div className="relative w-full h-full">
                <Image
                  src={specimens[2].imageSrc}
                  alt={specimens[2].name}
                  fill
                  sizes="(max-width: 768px) 100vw, 33vw"
                  className="object-contain filter drop-shadow-[0_15px_25px_rgba(0,0,0,0.8)] group-hover:scale-105 transition-all duration-500"
                />
              </div>
            </div>

            <div className="relative z-10 flex flex-col gap-2">
              <h3 className="font-[family-name:var(--font-anton)] text-xl sm:text-2xl uppercase tracking-tight text-white group-hover:text-teal-300 transition-colors">
                {specimens[2].name}
              </h3>
              <p className="text-xs text-white/70 font-light leading-relaxed line-clamp-3">
                {specimens[2].description}
              </p>
            </div>
          </div>

          {/* ---------------------------------------------------------------------
              CARD 4 (Row 2, Columns 5 to 8): Emmental Doré
             --------------------------------------------------------------------- */}
          <div
            onMouseEnter={() => setActiveCard("emmental")}
            onMouseLeave={() => setActiveCard(null)}
            className={`group md:col-span-4 relative rounded-3xl p-6 sm:p-7 transition-all duration-500 cursor-pointer overflow-hidden backdrop-blur-2xl ${
              specimens[3].rotation
            } ${
              activeCard === "emmental"
                ? "shadow-[0_0_45px_rgba(234,179,8,0.35)] border-amber-400/60 -translate-y-2"
                : "border-white/10 shadow-2xl"
            } bg-gradient-to-br from-[#1C1605]/90 via-[#0E0B02]/95 to-[#010410] border`}
          >
            <div className="flex items-center justify-between gap-4 mb-5 relative z-10">
              <span className="text-[10px] font-mono font-medium text-amber-300 uppercase tracking-widest px-2.5 py-0.5 rounded bg-amber-500/10 border border-amber-400/20">
                {specimens[3].category}
              </span>
              <span className="text-[11px] font-mono text-white/40">
                N°03 // AMBRE
              </span>
            </div>

            <div className="relative z-10 w-full h-[230px] sm:h-[260px] rounded-2xl bg-white/[0.03] border border-white/[0.06] overflow-hidden flex items-center justify-center p-4 mb-5 group-hover:border-amber-400/30 transition-colors">
              <div className="relative w-full h-full">
                <Image
                  src={specimens[3].imageSrc}
                  alt={specimens[3].name}
                  fill
                  sizes="(max-width: 768px) 100vw, 33vw"
                  className="object-contain filter drop-shadow-[0_15px_25px_rgba(0,0,0,0.8)] group-hover:scale-105 transition-all duration-500"
                />
              </div>
            </div>

            <div className="relative z-10 flex flex-col gap-2">
              <h3 className="font-[family-name:var(--font-anton)] text-xl sm:text-2xl uppercase tracking-tight text-white group-hover:text-amber-300 transition-colors">
                {specimens[3].name}
              </h3>
              <p className="text-xs text-white/70 font-light leading-relaxed line-clamp-3">
                {specimens[3].description}
              </p>
            </div>
          </div>

          {/* ---------------------------------------------------------------------
              CARD 5 (Row 2, Columns 9 to 12): Popcorn Maïs
             --------------------------------------------------------------------- */}
          <div
            onMouseEnter={() => setActiveCard("popcorn")}
            onMouseLeave={() => setActiveCard(null)}
            className={`group md:col-span-4 relative rounded-3xl p-6 sm:p-7 transition-all duration-500 cursor-pointer overflow-hidden backdrop-blur-2xl ${
              specimens[4].rotation
            } ${
              activeCard === "popcorn"
                ? "shadow-[0_0_40px_rgba(244,63,94,0.3)] border-rose-400/60 -translate-y-2"
                : "border-white/10 shadow-2xl"
            } bg-gradient-to-br from-[#240A14]/90 via-[#120409]/95 to-[#010410] border`}
          >
            <div className="flex items-center justify-between gap-4 mb-5 relative z-10">
              <span className="text-[10px] font-mono font-medium text-rose-300 uppercase tracking-widest px-2.5 py-0.5 rounded bg-rose-500/10 border border-rose-400/20">
                {specimens[4].category}
              </span>
              <span className="text-[11px] font-mono text-white/40">
                N°04 // MAÏS
              </span>
            </div>

            <div className="relative z-10 w-full h-[230px] sm:h-[260px] rounded-2xl bg-white/[0.03] border border-white/[0.06] overflow-hidden flex items-center justify-center p-4 mb-5 group-hover:border-rose-400/30 transition-colors">
              <div className="relative w-full h-full">
                <Image
                  src={specimens[4].imageSrc}
                  alt={specimens[4].name}
                  fill
                  sizes="(max-width: 768px) 100vw, 33vw"
                  className="object-contain filter drop-shadow-[0_15px_25px_rgba(0,0,0,0.8)] group-hover:scale-105 transition-all duration-500"
                />
              </div>
            </div>

            <div className="relative z-10 flex flex-col gap-2">
              <h3 className="font-[family-name:var(--font-anton)] text-xl sm:text-2xl uppercase tracking-tight text-white group-hover:text-rose-300 transition-colors">
                {specimens[4].name}
              </h3>
              <p className="text-xs text-white/70 font-light leading-relaxed line-clamp-3">
                {specimens[4].description}
              </p>
            </div>
          </div>
        </div>

        {/* =========================================================================
            STRONG CENTERED CALL TO ACTION
           ========================================================================= */}
        <div className="mt-24 sm:mt-32 lg:mt-40 flex flex-col items-center justify-center text-center">
          <span className="text-[11px] font-mono uppercase tracking-[0.3em] text-amber-400 mb-4 block">
            L&apos;EXPÉDITION COMMENCE ICI
          </span>
          <h3 className="font-[family-name:var(--font-anton)] text-4xl sm:text-6xl lg:text-7xl uppercase tracking-tight text-white mb-8">
            PRÊT À CROQUER LE MYSTÈRE ?
          </h3>

          <Link
            href="#univers"
            className="group relative inline-flex items-center gap-5 pl-8 pr-3 py-4 rounded-full bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-500 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold text-base sm:text-lg shadow-[0_0_50px_rgba(37,99,235,0.4)] hover:shadow-[0_0_70px_rgba(37,99,235,0.6)] transition-all duration-300 transform active:scale-95"
          >
            <span className="tracking-wide uppercase font-[family-name:var(--font-anton)] text-xl sm:text-2xl">
              ENTRER DANS L&apos;UNIVERS
            </span>
            <span className="flex items-center justify-center w-11 h-11 rounded-full bg-white text-slate-950 group-hover:translate-x-1 transition-transform duration-300 shadow-md">
              <svg
                className="w-5 h-5"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.5"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"
                />
              </svg>
            </span>
          </Link>
        </div>
      </div>

      {/* =========================================================================
          STRIKING FOOTER (FINAL PAGE OF AN ART BOOK)
         ========================================================================= */}
      <footer id="contact" className="relative z-10 mt-32 sm:mt-44 lg:mt-56 pt-20 border-t border-white/10 bg-[#000208]">
        <div className="max-w-7xl mx-auto px-6 sm:px-10 lg:px-16">
          {/* Top row: Brand Statement & Navigation */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-12 lg:gap-16 pb-20">
            {/* Left Column: Brand statement */}
            <div className="md:col-span-5 flex flex-col gap-5">
              <div className="flex items-center gap-3">
                <span className="w-3 h-3 rounded-full bg-amber-400 shadow-[0_0_10px_rgba(251,191,36,0.9)]" />
                <span className="font-[family-name:var(--font-anton)] text-2xl tracking-[0.08em] text-white">
                  CHIPSY
                </span>
              </div>
              <p className="text-sm sm:text-base text-white/60 font-light leading-relaxed max-w-sm">
                CHIPSY célèbre l&apos;art du croustillant et la magie des
                saveurs partagées. Fabriqué avec passion pour réveiller vos sens
                et transformer chaque instant en aventure gourmande.
              </p>
              <span className="text-xs font-mono text-amber-400/80">
                PRODUIT PAR NUTRI • FABRIQUÉ AVEC FIERTÉ
              </span>
            </div>

            {/* Middle Column: Navigation links */}
            <div className="md:col-span-4 grid grid-cols-2 gap-6">
              <div>
                <h4 className="text-xs font-mono uppercase tracking-widest text-white/40 mb-4">
                  Navigation
                </h4>
                <ul className="space-y-2.5 text-sm">
                  <li>
                    <Link
                      href="#"
                      className="text-white/70 hover:text-white transition-colors"
                    >
                      Accueil
                    </Link>
                  </li>
                  <li>
                    <Link
                      href="#saveurs"
                      className="text-white/70 hover:text-white transition-colors"
                    >
                      Saveurs
                    </Link>
                  </li>
                  <li>
                    <Link
                      href="#univers"
                      className="text-white/70 hover:text-white transition-colors"
                    >
                      Univers
                    </Link>
                  </li>
                  <li>
                    <Link
                      href="#mascotte"
                      className="text-white/70 hover:text-white transition-colors"
                    >
                      Mascotte Chipo
                    </Link>
                  </li>
                  <li>
                    <Link
                      href="#contact"
                      className="text-white/70 hover:text-white transition-colors"
                    >
                      Contact
                    </Link>
                  </li>
                </ul>
              </div>

              <div>
                <h4 className="text-xs font-mono uppercase tracking-widest text-white/40 mb-4">
                  Légal
                </h4>
                <ul className="space-y-2.5 text-sm">
                  <li>
                    <Link
                      href="#mentions"
                      className="text-white/50 hover:text-white transition-colors"
                    >
                      Mentions Légales
                    </Link>
                  </li>
                  <li>
                    <Link
                      href="#confidentialite"
                      className="text-white/50 hover:text-white transition-colors"
                    >
                      Confidentialité
                    </Link>
                  </li>
                  <li>
                    <Link
                      href="#cookies"
                      className="text-white/50 hover:text-white transition-colors"
                    >
                      Cookies
                    </Link>
                  </li>
                  <li>
                    <Link
                      href="#presse"
                      className="text-white/50 hover:text-white transition-colors"
                    >
                      Espace Presse
                    </Link>
                  </li>
                </ul>
              </div>
            </div>

            {/* Right Column: Social Links */}
            <div className="md:col-span-3 flex flex-col gap-4">
              <h4 className="text-xs font-mono uppercase tracking-widest text-white/40">
                Réseaux & Communauté
              </h4>
              <div className="flex flex-col gap-2.5 text-sm">
                <Link
                  href="https://instagram.com"
                  target="_blank"
                  className="text-white/70 hover:text-amber-400 transition-colors flex items-center justify-between py-1 border-b border-white/5"
                >
                  <span>Instagram</span>
                  <span className="text-xs font-mono text-white/40">@chipsy</span>
                </Link>
                <Link
                  href="https://tiktok.com"
                  target="_blank"
                  className="text-white/70 hover:text-amber-400 transition-colors flex items-center justify-between py-1 border-b border-white/5"
                >
                  <span>TikTok</span>
                  <span className="text-xs font-mono text-white/40">@chipsy_officiel</span>
                </Link>
                <Link
                  href="https://youtube.com"
                  target="_blank"
                  className="text-white/70 hover:text-amber-400 transition-colors flex items-center justify-between py-1 border-b border-white/5"
                >
                  <span>YouTube</span>
                  <span className="text-xs font-mono text-white/40">Chipsy World</span>
                </Link>
                <Link
                  href="https://twitter.com"
                  target="_blank"
                  className="text-white/70 hover:text-amber-400 transition-colors flex items-center justify-between py-1 border-b border-white/5"
                >
                  <span>X / Twitter</span>
                  <span className="text-xs font-mono text-white/40">@chipsysnacks</span>
                </Link>
              </div>
            </div>
          </div>

          {/* Art-Book Final Typographic Monument: Gigantic Dominant "CHIPSY" */}
          <div className="relative pt-12 pb-6 border-t border-white/10 overflow-hidden flex flex-col items-center">
            <h2 className="font-[family-name:var(--font-anton)] text-[22vw] leading-[0.78] tracking-[-0.03em] uppercase text-center text-white/[0.07] select-none pointer-events-none hover:text-white/10 transition-colors duration-700">
              CHIPSY
            </h2>

            {/* Copyright & Disclaimer Line */}
            <div className="w-full mt-8 pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-white/40">
              <span>© 2026 Chipsy by Nutri. Tous droits réservés.</span>
              <span className="text-center sm:text-right">
                ÉDITION NUMÉRIQUE ART-BOOK • VOLUME I
              </span>
            </div>
          </div>
        </div>
      </footer>
    </section>
  );
}
