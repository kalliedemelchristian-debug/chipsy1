"use client";

import { useState, useRef, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import StorytellingSection from "./components/StorytellingSection";
import DiscoverySection from "./components/DiscoverySection";

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeNav, setActiveNav] = useState("Accueil");

  // Cursor following spotlight state
  const heroRef = useRef<HTMLElement>(null);
  const [isInside, setIsInside] = useState(false);
  const [coords, setCoords] = useState({ x: -1000, y: -1000 });

  const targetRef = useRef({ x: -1000, y: -1000 });
  const currentRef = useRef({ x: -1000, y: -1000 });
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    let active = true;

    const animate = () => {
      if (!active) return;

      // Silky smooth lerp easing (factor 0.12)
      const dx = targetRef.current.x - currentRef.current.x;
      const dy = targetRef.current.y - currentRef.current.y;

      if (Math.abs(dx) > 0.05 || Math.abs(dy) > 0.05) {
        currentRef.current.x += dx * 0.12;
        currentRef.current.y += dy * 0.12;
        setCoords({
          x: Math.round(currentRef.current.x * 10) / 10,
          y: Math.round(currentRef.current.y * 10) / 10,
        });
      }

      rafRef.current = requestAnimationFrame(animate);
    };

    rafRef.current = requestAnimationFrame(animate);

    return () => {
      active = false;
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, []);

  const handleMouseMove = (e: React.MouseEvent<HTMLElement>) => {
    const rect = heroRef.current?.getBoundingClientRect();
    if (!rect) return;
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (!isInside) {
      currentRef.current = { x, y };
      setCoords({ x, y });
      setIsInside(true);
    }

    targetRef.current = { x, y };
  };

  const handleMouseEnter = (e: React.MouseEvent<HTMLElement>) => {
    const rect = heroRef.current?.getBoundingClientRect();
    if (!rect) return;
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    targetRef.current = { x, y };
    currentRef.current = { x, y };
    setCoords({ x, y });
    setIsInside(true);
  };

  const handleMouseLeave = () => {
    setIsInside(false);
  };

  const navLinks = [
    { name: "Accueil", href: "#" },
    { name: "Saveurs", href: "#saveurs" },
    { name: "Mascotte", href: "#mascotte" },
    { name: "Univers", href: "#univers" },
    { name: "Contact", href: "#contact" },
  ];

  return (
    <>
      {/* =========================================================================
          CHIPSY HERO SECTION (EXACT ORIGINAL - UNMODIFIED)
         ========================================================================= */}
      <main
        ref={heroRef}
        onMouseMove={handleMouseMove}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        className="relative w-full h-[100dvh] min-h-[640px] flex flex-col justify-between overflow-hidden bg-[#020B2E] select-none"
      >
        {/* =========================================================================
            1. EXISTING HERO BACKGROUND (ATMOSPHERE & LIGHTING)
           ========================================================================= */}
        {/* Deep Vignette towards pure near-black on edges */}
        <div
          className="pointer-events-none absolute inset-0 z-0"
          style={{
            background:
              "radial-gradient(ellipse 90% 80% at 50% 50%, rgba(2, 11, 46, 0.4) 0%, rgba(2, 8, 30, 0.85) 60%, #00030c 100%)",
          }}
        />

        {/* Soft Blue Glow in the Center */}
        <div
          className="pointer-events-none absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[65vw] max-w-[900px] h-[55vh] max-h-[650px] rounded-full blur-[110px] md:blur-[140px] z-0 animate-pulse-glow"
          style={{
            background:
              "radial-gradient(circle, rgba(37, 99, 235, 0.32) 0%, rgba(29, 78, 216, 0.22) 38%, rgba(15, 30, 95, 0.12) 65%, transparent 80%)",
          }}
        />

        {/* Subtle Concentrated Core Light */}
        <div
          className="pointer-events-none absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[30vw] max-w-[420px] h-[25vh] max-h-[300px] rounded-full blur-[70px] z-0"
          style={{
            background:
              "radial-gradient(circle, rgba(96, 165, 250, 0.22) 0%, rgba(59, 130, 246, 0.14) 50%, transparent 80%)",
          }}
        />

        {/* BASE IMAGE (BG_IMAGE_1) */}
        <div className="pointer-events-none absolute inset-0 z-[1] overflow-hidden">
          <Image
            src="/images/bg-hero.jpg"
            alt="Chipsy Base Hero"
            fill
            priority
            sizes="100vw"
            className="object-cover object-center select-none"
          />
        </div>

        {/* Editorial Film Grain Overlay */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 z-[2] opacity-[0.035] mix-blend-screen"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
          }}
        />

        {/* =========================================================================
            2. CURSOR-FOLLOWING CHARACTER REVEAL (BG_IMAGE_2)
               Above hero background (z-[1]/z-[2]), below text/UI (z-10, z-20, z-30).
               Spotlight radius: 260px, soft feathered edge, pointer-events: none.
           ========================================================================= */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 z-[5] overflow-hidden transition-opacity duration-300 ease-out"
          style={{
            opacity: isInside ? 1 : 0,
            WebkitMaskImage: `radial-gradient(circle 260px at ${coords.x}px ${coords.y}px, black 0%, black 130px, rgba(0, 0, 0, 0.5) 195px, transparent 260px)`,
            maskImage: `radial-gradient(circle 260px at ${coords.x}px ${coords.y}px, black 0%, black 130px, rgba(0, 0, 0, 0.5) 195px, transparent 260px)`,
          }}
        >
          <Image
            src="/images/reveal-character.jpg"
            alt="Chipsy Character Reveal"
            fill
            priority
            sizes="100vw"
            className="object-cover object-center select-none"
          />
        </div>

        {/* Subtle ambient golden glow centered on cursor to enhance reveal atmosphere */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -translate-x-1/2 -translate-y-1/2 rounded-full z-[6] transition-opacity duration-300 ease-out"
          style={{
            left: `${coords.x}px`,
            top: `${coords.y}px`,
            width: "520px",
            height: "520px",
            opacity: isInside ? 0.28 : 0,
            background:
              "radial-gradient(circle, rgba(251, 191, 36, 0.25) 0%, rgba(245, 158, 11, 0.12) 35%, rgba(59, 130, 246, 0.05) 60%, transparent 75%)",
            mixBlendMode: "screen",
          }}
        />

        {/* =========================================================================
            3. SLIM TOP NAVIGATION (Z-INDEX 30 - STRICTLY ABOVE REVEAL)
           ========================================================================= */}
        <header className="relative z-30 w-full pt-6 md:pt-8 px-6 sm:px-10 md:px-14 lg:px-20">
          <div className="flex items-center justify-between">
            {/* Logo with sleek brand capsule */}
            <Link
              href="/"
              className="group flex items-center gap-3 py-2 px-4 rounded-full bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 backdrop-blur-md transition-all duration-300"
            >
              <span className="relative flex items-center justify-center w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 group-hover:scale-105 transition-transform duration-300">
                <span className="w-2.5 h-2.5 rounded-full bg-gradient-to-tr from-amber-500 to-amber-300 shadow-[0_0_8px_rgba(245,158,11,0.8)]" />
              </span>
              <span className="font-[family-name:var(--font-anton)] text-xl sm:text-2xl tracking-[0.08em] text-white">
                CHIPSY
              </span>
            </Link>

            {/* Desktop Navigation Links */}
            <nav className="hidden md:flex items-center gap-1 lg:gap-2 px-4 py-1.5 rounded-full bg-white/[0.03] border border-white/[0.08] backdrop-blur-xl">
              {navLinks.map((link) => {
                const isActive = activeNav === link.name;
                return (
                  <Link
                    key={link.name}
                    href={link.href}
                    onClick={() => setActiveNav(link.name)}
                    className={`relative px-4 py-2 text-xs lg:text-sm font-medium tracking-wide transition-all duration-200 rounded-full ${
                      isActive
                        ? "text-white bg-white/10 shadow-[inset_0_1px_1px_rgba(255,255,255,0.15)]"
                        : "text-white/60 hover:text-white hover:bg-white/[0.04]"
                    }`}
                  >
                    {link.name}
                    {isActive && (
                      <span className="absolute bottom-1.5 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-amber-400" />
                    )}
                  </Link>
                );
              })}
            </nav>

            {/* Right Status / Quick Action Pill (desktop) & Hamburger (mobile) */}
            <div className="flex items-center gap-3">
              <div className="hidden lg:flex items-center gap-2 py-2 px-4 rounded-full bg-white/[0.03] border border-white/[0.08] backdrop-blur-md">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_6px_rgba(52,211,153,0.8)]" />
                <span className="text-[11px] uppercase tracking-widest text-white/70 font-medium">
                  Édition 2026
                </span>
              </div>

              {/* Mobile Hamburger Button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                aria-label="Toggle navigation menu"
                className="md:hidden flex items-center justify-center w-11 h-11 rounded-full bg-white/[0.05] border border-white/10 text-white/80 hover:text-white backdrop-blur-md transition-all active:scale-95"
              >
                {mobileMenuOpen ? (
                  <svg
                    className="w-5 h-5"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M6 18L18 6M6 6l12 12"
                    />
                  </svg>
                ) : (
                  <svg
                    className="w-5 h-5"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"
                    />
                  </svg>
                )}
              </button>
            </div>
          </div>

          {/* Mobile Dropdown Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden mt-3 p-4 rounded-2xl bg-[#040E3B]/95 border border-white/10 backdrop-blur-2xl shadow-2xl animate-in fade-in slide-in-from-top-2 duration-200">
              <nav className="flex flex-col gap-2">
                {navLinks.map((link) => (
                  <Link
                    key={link.name}
                    href={link.href}
                    onClick={() => {
                      setActiveNav(link.name);
                      setMobileMenuOpen(false);
                    }}
                    className={`text-left px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                      activeNav === link.name
                        ? "bg-white/10 text-white font-semibold"
                        : "text-white/70 hover:text-white hover:bg-white/[0.05]"
                    }`}
                  >
                    {link.name}
                  </Link>
                ))}
              </nav>
            </div>
          )}
        </header>

        {/* =========================================================================
            4. GIGANTIC DOMINANT "CHIPSY" HEADLINE (Z-INDEX 10 - STRICTLY ABOVE REVEAL)
           ========================================================================= */}
        <section className="relative z-10 w-full flex items-center justify-center my-auto px-4 overflow-hidden pointer-events-none">
          <h1
            className="font-[family-name:var(--font-anton)] text-white text-center uppercase tracking-[-0.02em] leading-[0.82] text-[20vw] sm:text-[21vw] md:text-[20vw] lg:text-[19vw] xl:text-[18.5vw] drop-shadow-[0_10px_35px_rgba(0,0,0,0.6)] select-none"
            style={{
              textShadow:
                "0 0 60px rgba(59, 130, 246, 0.25), 0 0 120px rgba(37, 99, 235, 0.15)",
            }}
          >
            CHIPSY
          </h1>
        </section>

        {/* =========================================================================
            5. BOTTOM AREA (Z-INDEX 20 - STRICTLY ABOVE REVEAL)
           ========================================================================= */}
        <footer className="relative z-20 w-full pb-8 sm:pb-10 md:pb-12 px-6 sm:px-10 md:px-14 lg:px-20">
          <div className="flex flex-col lg:flex-row items-start lg:items-end justify-between gap-8 lg:gap-12">
            {/* Left Column: Pill label + Editorial Description */}
            <div className="max-w-xl space-y-3.5">
              <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-white/[0.05] border border-white/10 backdrop-blur-md">
                <span className="w-2 h-2 rounded-full bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.9)] animate-pulse" />
                <span className="text-xs sm:text-[13px] font-medium tracking-wide text-white/90">
                  Entrez dans un monde où le croquant prend vie
                </span>
              </div>

              <p className="text-sm sm:text-base md:text-lg text-white/70 font-light leading-relaxed tracking-normal max-w-lg">
                Un univers de saveurs fromagées, de personnages malicieux et de
                croustillant à découvrir.
              </p>
            </div>

            {/* Right Column: Two Action Buttons */}
            <div className="flex flex-wrap sm:flex-nowrap items-center gap-3 sm:gap-4 w-full lg:w-auto">
              {/* Primary Button: "Découvrir Chipsy →" */}
              <Link
                href="#univers"
                className="group relative flex items-center justify-between gap-4 pl-6 pr-2.5 py-2.5 rounded-full bg-gradient-to-r from-amber-500 via-amber-400 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-semibold text-sm sm:text-base shadow-[0_4px_24px_rgba(245,158,11,0.3)] hover:shadow-[0_6px_32px_rgba(245,158,11,0.45)] transition-all duration-300 transform active:scale-95"
              >
                <span className="tracking-tight whitespace-nowrap">
                  Découvrir Chipsy
                </span>
                <span className="flex items-center justify-center w-8 sm:w-9 h-8 sm:h-9 rounded-full bg-slate-950 text-white group-hover:translate-x-0.5 transition-transform duration-300">
                  <svg
                    className="w-4 h-4"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.5"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"
                    />
                  </svg>
                </span>
              </Link>

              {/* Secondary Button: "Rencontrer la mascotte →" */}
              <Link
                href="#univers"
                className="group relative flex items-center justify-between gap-4 pl-6 pr-2.5 py-2.5 rounded-full bg-white/[0.04] hover:bg-white/[0.09] text-white border border-white/15 hover:border-white/30 backdrop-blur-md font-medium text-sm sm:text-base transition-all duration-300 active:scale-95"
              >
                <span className="tracking-tight text-white/90 group-hover:text-white whitespace-nowrap">
                  Rencontrer la mascotte
                </span>
                <span className="flex items-center justify-center w-8 sm:w-9 h-8 sm:h-9 rounded-full bg-white/10 group-hover:bg-white/20 text-white group-hover:translate-x-0.5 transition-all duration-300">
                  <svg
                    className="w-4 h-4"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"
                    />
                  </svg>
                </span>
              </Link>
            </div>
          </div>
        </footer>
      </main>

      {/* =========================================================================
          CINEMATIC SCROLL-DRIVEN STORYTELLING SECTION (NEXT SECTION DIRECTLY AFTER HERO)
         ========================================================================= */}
      <StorytellingSection />

      {/* =========================================================================
          CHIPSY DISCOVERY: INTERACTIVE DIGITAL ARCHIVE (5 CARDS & ART-BOOK FOOTER)
         ========================================================================= */}
      <DiscoverySection />
    </>
  );
}
